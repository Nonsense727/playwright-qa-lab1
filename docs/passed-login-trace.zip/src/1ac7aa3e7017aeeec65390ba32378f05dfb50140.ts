import { test, expect } from '@playwright/test';

/*
 * Лаборатори №1 — Playwright UI автомат тест
 *
 * Энэ файл нь https://www.saucedemo.com вэбсайт дээрх дарааллыг автоматжуулсан
 * 3 тестийг агнуулсан болно:
 *   1. Амжилттай нэвтрэх — зөв хэрэглэгчийн нэр/нууц үгээр нэвтэрснийг
 *      баталгүйцүүлж, бүтээгдэхүүн хуудсыг (Products page) харуулна.
 *   2. Амжилтгүй нэвтрэх — буруу нууц үгийг оруулсан үед
 *      алдааны мессеж (error message) гарж байгааг шалгана.
 *   3. Бараа сагслах — нэвтэрсний дараа антиварыг сагслах үйлдлийг
 *      автоматжуулж, сагсын дээрээ зургийн шалгуурлалт хийнэ.
 *
 * Локаторуудын сонголт (XPath-ийг зайлсхий):
 *   - getByPlaceholder — placeholder тексттэй input уруу нь зориулсон,
 *     жишээ нь "Username", "Password" оролтын төлөвлөртэй элементүүд.
 *   - getByRole — элементийн дүрэм (role) ба нэртэй button/link-ийг
 *     хайхад ашигладаг; жишээ нь "Login" товчин дээр дарах.
 *   - getByText — хуудасны текст мэнджерд (heading, paragraph) дээр
 *     үндэслэн олддог; жишээ нь "Products" гэсэн гарчгийг шалгах.
 *   - getByTestId — data-test аргументтэй элементүүдийг зориулна.
 * Эд бүрийг XPath-оор биш, семантик ба DOM-тҳан үндэслэсэн
 * локаторуудаас ашиглах нь дарагдсан, өргөдөлттэй, 
 * урьдрал болон хянаххан их болдог.
 */

/*
 * Тест 1: Амжилттай нэвтрэх
 *
 * Зорилтот: standard_user / secret_sauce хэрэглэгчийг нэвтрүүлж,
 * "Products" хуудсанд очсонд баталгүйцүүлэх.
 */
test('Амжилттай нэвтрэх', async ({ page }) => {
  // 1. Бакетсайтруу очих
  await page.goto('/');

  // 2. Нэр ба нууц үгийг оруулж авах (placeholder текстээр олох)
  //    Playwright-ийн Auto-wait ажиллах арга нь элемент бэлэн болох
  //    хүртэл үлдэнэ — энэ нь Selenium-ийн гараарын explicit wait-с
  //    аль болох давуу тал.
  await page.getByPlaceholder('Username').fill('standard_user');
  await page.getByPlaceholder('Password').fill('secret_sauce');

  // 3. "Login" товчийг дарах (дүрм (role) ба нэртэй button-ийг олох)
  await page.getByRole('button', { name: 'Login' }).click();

  // 4. БаталгҐүйцүүлэх:
  //    - "Products" гарчинг (heading) үзүүлсэн байгааг шалгах
  await expect(page.getByText('Products', { exact: true })).toBeVisible();

  //    - URL дэхред "/inventory.html" болж солигдсон болно
  await expect(page).toHaveURL(/.*inventory\.html/);

  // 5. Төгсгөлд logout хийх (хуваарилсан тестийн чист байдал)
  await page.getByRole('button', { name: 'Open Menu' }).click();
  await page.getByRole('link', { name: 'Logout' }).click();
  await expect(page).toHaveURL('/');
});

/*
 * Тест 2: Буруу нууц үгээр нэвтрэх (амжилтгүй нэвтрэх)
 *
 * Зорилтот: буруу нууц үг оруулсан үед
 * "Username and password do not match any user in this service" —
 * алдааны мессеж гарч байгааг шалгах.
 */
test('Буруу нууц үгээр нэвтрэх үед алдааны мессеж гарна', async ({ page }) => {
  // 1. Бакетсайтруу очих
  await page.goto('/');

  // 2. Хэрэглэгчийн нэртэй бөгөөд буруу нууц үг оруулах
  await page.getByPlaceholder('Username').fill('standard_user');
  await page.getByPlaceholder('Password').fill('буруу_нууц_үг_123');

  // 3. Login товчийг дарах
  await page.getByRole('button', { name: 'Login' }).click();

  // 4. Алдааны мессежийг шалгах — энэ элементийг data-test="error"
  //    аргументтэй div-с олох боломжтой (getByTestId-ийг ашиглан)
  await expect(page.getByTestId('error')).toContainText(
    'Username and password do not match any user in this service'
  );
});

/*
 * Тест 3: Нэвтэрсний дараа бараа сагслах (post-login action)
 *
 * Зорилтов: нэвтэрсний дараа "Sauce Labs Backpack"-ийг
 * сагслах товч дарж, сагс дээр үзсэн бүтээгдэхүүнт зургийг
 * шалгах.
 */
test('Нэвтэрсний дараа бараа сагслах', async ({ page }) => {
  // 1. Нэвтрэх
  await page.goto('/');
  await page.getByPlaceholder('Username').fill('standard_user');
  await page.getByPlaceholder('Password').fill('secret_sauce');
  await page.getByRole('button', { name: 'Login' }).click();

  // 2. Баталгүйцүүлэх: Products хуудас үзүүлсэн
  await expect(page.getByText('Products', { exact: true })).toBeVisible();

  // 3. "Sauce Labs Backpack" бараагийн "Add to cart" товчийг дарах.
  //    Энд data-test="add-to-sauce-labs-backpack" аргументтэй
  //    товчийг локатораар ашигласан болно — энэ нь далд UI-ийг
  //    бүрэн семантик ба уял хүрээнд ажиллуулна.
  await page.getByRole('button', { name: 'Add to cart' }).first().click();

  // 4. Сагс руу шилжих (data-test="shopping-cart-link" аргументтэй link-ийг ашиглана)
  await page.getByTestId('shopping-cart-link').click();
  await expect(page).toHaveURL(/.*cart\.html/);

  // 5. Сагслын дээр "Sauce Labs Backpack" байгааг шалгах
  await expect(page.getByText('Sauce Labs Backpack', { exact: true })).toBeVisible();

  // 6. Logout хийж, тестийг зөв төгсгө
  await page.getByRole('button', { name: 'Open Menu' }).click();
  await page.getByRole('link', { name: 'Logout' }).click();
  await expect(page).toHaveURL('/');
});
